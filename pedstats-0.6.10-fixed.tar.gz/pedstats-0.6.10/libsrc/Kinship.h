////////////////////////////////////////////////////////////////////// 
// libsrc/Kinship.h 
// (c) 2000-2007 Goncalo Abecasis (c) 2002-2007 Jan Wigginton
// 
// This file is distributed as part of the PEDSTATS source code package   
// and may not be redistributed in any form, without prior written    
// permission from the author. Permission is granted for you to       
// modify this file for your own personal use, but modified versions  
// must retain this copyright notice and must not be distributed.     
// 
// Permission is granted for you to use this file to compile PEDSTATS.    
// 
// All computer programs have bugs. Use this file at your own risk.   
// 
// Tuesday December 18, 2007
// 
 
#ifndef __KINSHIP_H__
#define __KINSHIP_H__

#include "Pedigree.h"
#include "MathMatrix.h"

class Kinship
   {
   public:
      Matrix    allPairs;
      Family *  fam;

      Kinship() : allPairs()
         { fam = NULL; }

      void Setup(Family & f);

      bool isInbred();

      double operator () (Person & p1, Person & p2);

   };

#endif

 
